package com.example.parcelables;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;
public class Datos implements Parcelable{
    public String Nombre;
    public String Telefono;
    public String Correo;

    protected Datos(Parcel in) {
        Nombre = in.readString();
        Telefono = in.readString();
        Correo = in.readString();
    }

    public static final Creator<Datos> CREATOR = new Creator<Datos>() {
        @Override
        public Datos createFromParcel(Parcel in) {
            return new Datos(in);
        }

        @Override
        public Datos[] newArray(int size) {
            return new Datos[size];
        }
    };

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String correo) {
        Correo = correo;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String telefono) {
        Telefono = telefono;
    }


    public Datos(String correo, String telefono, String nombre) {
        Correo = correo;
        Telefono = telefono;
        Nombre = nombre;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(Nombre);
        dest.writeString(Telefono);
        dest.writeString(Correo);
    }
}

