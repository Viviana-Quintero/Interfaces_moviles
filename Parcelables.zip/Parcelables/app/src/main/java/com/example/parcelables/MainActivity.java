package com.example.parcelables;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText Nombre, Telefono, Correo;

    Button lanzar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Nombre=this.findViewById(R.id.txtA1Nombre);
        Telefono=this.findViewById(R.id.txtA1Telefono);
        Correo=this.findViewById(R.id.txtA1Correo);
        lanzar=this.findViewById(R.id.btnA1Lanzar);

        lanzar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pasaParcel(v);
            }
        });
    }

    private void pasaParcel(View v) {
        Datos datos = new Datos(Correo.getText().toString(),Telefono.getText().toString(),Nombre.getText().toString());;
        Intent intent = new Intent(this, pantalla_2.class);
        intent.putExtra("datosparce",datos);
        startActivity(intent);
    }


}