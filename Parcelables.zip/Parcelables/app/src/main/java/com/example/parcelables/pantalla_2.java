package com.example.parcelables;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class pantalla_2 extends AppCompatActivity {
    TextView lblA2Nombre, lblA2Telefono, lblA2Correo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pantalla_2);
        lblA2Nombre=this.findViewById(R.id.lblA2Nombre);
        lblA2Telefono=this.findViewById(R.id.lblA2Telefono);
        lblA2Correo=this.findViewById(R.id.lblA2Correo);

        Datos datos = this.getIntent().getParcelableExtra("datosparce");
        lblA2Nombre.setText(datos.getNombre());
        lblA2Correo.setText(datos.getCorreo());
        lblA2Telefono.setText(datos.getTelefono());

    }
}
