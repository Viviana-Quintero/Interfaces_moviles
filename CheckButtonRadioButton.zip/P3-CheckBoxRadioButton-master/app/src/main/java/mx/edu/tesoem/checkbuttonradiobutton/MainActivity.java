package mx.edu.tesoem.checkbuttonradiobutton;

import static android.widget.Toast.LENGTH_SHORT;
import static android.widget.Toast.makeText;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnA1ChkRB, btnA1ChkCB;
    RadioButton rbHombre, rbMujer, rbOtros;
    CheckBox cbCasa, cbOficina, cbPublico;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rbHombre = this.findViewById(R.id.rbA1Hombre);
        rbMujer = this.findViewById(R.id.rbA1Mujer);
        rbOtros = this.findViewById(R.id.rbA1Otros);

        cbCasa = this.findViewById(R.id.chbA1Casa);
        cbOficina = this.findViewById(R.id.chbA1Oficina);
        cbPublico = this.findViewById(R.id.chbA1Publico);

        btnA1ChkCB = this.findViewById(R.id.btnA1chkCB);
        btnA1ChkRB = this.findViewById(R.id.btnA1chkRB);

        btnA1ChkRB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                acciones(v);
            }
        });
        btnA1ChkCB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                acciones(v);
            }
        });
    }


    private void acciones(View v) {
        if(v.getId() == R.id.rbA1Hombre){
            makeText(this,"Seleccionó Nombre",LENGTH_SHORT).show();
        }else
            if (v.getId() == R.id.rbA1Mujer){
                makeText(this,"Seleccionó Mujer",LENGTH_SHORT).show();
            }else
                if(v.getId() == R.id.rbA1Otros){
                    makeText(this,"Seleccionó Otros",LENGTH_SHORT).show();
                }else
                    if(v.getId() == R.id.btnA1chkCB){
                        checarCB();
                    }else
                        if(v.getId() == R.id.btnA1chkRB){
                            checarRB();
                        }
    }

    private void checarRB() {
        if(rbHombre.isChecked()){
            makeText(this,"Selecciono Hombre", LENGTH_SHORT).show();
        }
        if(rbMujer.isChecked()){
            makeText(this,"Selecciono Mujer", LENGTH_SHORT).show();
        }
        if(rbOtros.isChecked()){
            makeText(this,"Selecciono Otros", LENGTH_SHORT).show();
        }
    }

    private void checarCB() {
        if(cbCasa.isChecked()){
            makeText(this,"Internet CASA", LENGTH_SHORT).show();
        }
        if(cbOficina.isChecked()){
            makeText(this,"Internet Oficina", LENGTH_SHORT).show();
        }
        if(cbPublico.isChecked()){
            makeText(this,"Internet Público", LENGTH_SHORT).show();
        }
    }
}
