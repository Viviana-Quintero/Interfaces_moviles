package com.example.intentyputextras;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
public class pantalla_1 extends AppCompatActivity{
    TextView nombre,correo,telefono;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pantallla__1);
        nombre = this.findViewById(R.id.lblA3Nombre);
        correo = this.findViewById(R.id.lblA3Correo);
        telefono = this.findViewById(R.id.lblA3Telefono);
        Datos datos = getIntent().getParcelableExtra("datosparce");
        nombre.setText(datos.nombre);
        correo.setText(datos.correo);
        telefono.setText(datos.telefono);
    }
}
