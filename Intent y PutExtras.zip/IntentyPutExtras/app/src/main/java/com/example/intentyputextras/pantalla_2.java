package com.example.intentyputextras;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class pantalla_2 extends AppCompatActivity {
    TextView lblA2Nombre, lblA2Correo, lblA2Telefono;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pantalal_2);

        lblA2Nombre = this.findViewById(R.id.lblA2Nombre);
        lblA2Correo = this.findViewById(R.id.lblA2Correo);
        lblA2Telefono = this.findViewById(R.id.lblA2Telefono);

        Bundle datos = this.getIntent().getExtras();
        lblA2Nombre.setText(datos.getString("nombre"));
        lblA2Correo.setText(datos.getString("correo"));
        lblA2Telefono.setText(datos.getString("telefono"));
}
}
