package com.example.intentyputextras;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button btnA1Siguiente,btnA1Parce;
    EditText txtA1Nombre, txtA1Correo, txtA1Telefono;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        btnA1Siguiente = this.findViewById(R.id.btnA1Siguiente);
        btnA1Parce = this.findViewById(R.id.btnA1Parce);
        txtA1Nombre = this.findViewById(R.id.txtA1Nombre);
        txtA1Correo = this.findViewById(R.id.txtA1Correo);
        txtA1Telefono = this.findViewById(R.id.txtA1Telefono);

        btnA1Siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                siguiente(v);
            }
        });
        btnA1Parce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                parcel(v);
            }
        });
    }
    public void parcel(View v){
        Datos datos= new Datos(txtA1Nombre.getText().toString(),txtA1Correo.getText().toString(),txtA1Telefono.getText().toString());
        Intent intent = new Intent(this, pantalla_1.class);
        intent.putExtra("datosparce",datos);
        startActivity(intent);

    }
    public void siguiente(View v){
        Intent intent = new Intent(this, pantalla_2.class);
        intent.putExtra("nombre",txtA1Nombre.getText().toString());
        intent.putExtra("correo",txtA1Correo.getText().toString());
        intent.putExtra("telefono",txtA1Telefono.getText().toString());
        startActivity(intent);
    }
}
